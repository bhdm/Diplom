<?php

namespace Crm\MainBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class CrmMainBundle extends Bundle
{
}
