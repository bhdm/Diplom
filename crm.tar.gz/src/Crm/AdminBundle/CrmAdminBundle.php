<?php

namespace Crm\AdminBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class CrmAdminBundle extends Bundle
{
}
